#!/usr/bin/env bash
# Stops Invoice Ninja. Does not delete any data.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$SCRIPT_DIR/app/debian"

if [ ! -d "$APP_DIR" ]; then
	echo "Nothing to stop — Invoice Ninja hasn't been set up yet (run ./setup.sh first)."
	exit 0
fi

cd "$APP_DIR"
docker compose down
echo "Stopped. Your invoices/database/files are untouched."
