# Invoice Ninja (self-hosted)

Open-source invoicing/billing software — quotes, invoices, recurring
billing, expenses, client portal, payment gateway integrations.

## Why this folder just wraps the official repo

Unlike the TradeNote and SiYuan setups in this stack, I'm **not** shipping
a hand-written `docker-compose.yml` here. Invoice Ninja's real
architecture is nginx + PHP-FPM app + MySQL + Redis, wired together with
an nginx config tuned specifically to proxy to their PHP-FPM process.
That kind of config is easy to get subtly wrong (wrong `fastcgi_pass`
target, wrong timeout, wrong static-file routing) and hard to verify
without a live test — and I'd rather hand you the config Invoice Ninja's
own team writes and tests, than a plausible-looking one of my own that
might silently misbehave on file uploads or PDF generation.

`setup.sh` clones `invoiceninja/dockerfiles` (the `debian` branch, which
is what Invoice Ninja's own self-host docs currently point to) and
walks you through generating `.env` — domain, admin login, database
passwords, and the app encryption key — then starts it.

## Setup

```bash
cd invoiceninja
chmod +x setup.sh stop.sh
./setup.sh
```

You'll be prompted for:
- **Domain/URL** — e.g. `http://localhost:8003` for local-only use, or
  `https://invoices.yourdomain.com` if this will be reachable externally
  (in which case put it behind a reverse proxy with TLS — see note below)
- **Admin email + password** — this creates your first login automatically
  on first boot

Everything else (database credentials, the app encryption key) is
generated for you with real random values — nothing is left as a
guessable default.

The script prints the URL to open once containers are up. First boot
takes 30-60 seconds while MySQL initializes.

**Important first-login step:** once you've confirmed you can log in,
open `invoiceninja/app/debian/.env` and delete the `IN_USER_EMAIL` and
`IN_PASSWORD` lines, then `docker compose up -d` again (from
`invoiceninja/app/debian/`) to restart with them removed. Those two
variables exist only to seed the first account — leaving them in place
means anyone who reads that file could see your admin password in plain
text indefinitely.

## Stopping

```bash
./stop.sh
```

Keeps all data (invoices, clients, files, database) intact.

## Updating

```bash
cd app
git pull
cd debian
docker compose pull
docker compose up -d
```

Your `.env` is protected from being overwritten by `git pull` (the setup
script marks it with `git update-index --skip-worktree` on first clone),
so pulling updates won't touch your real credentials.

## Where your data lives

- **Invoices/clients/settings**: in the `mysql` container's data volume
  (defined in `app/debian/docker-compose.yml`) — back this up like any
  production database.
- **Uploaded files/PDFs/logos**: in the `app_public` / `app_storage`
  volumes defined in the same compose file.

## If you expose this beyond your home network

Don't point a public domain straight at port 8003 (or whatever port you
chose) without TLS in front of it. Put Invoice Ninja behind a reverse
proxy (Nginx, Caddy, or Traefik) that terminates HTTPS, and set
`REQUIRE_HTTPS=true` in `.env` once that's in place — invoices routinely
contain client PII and payment details, so this one is worth doing
properly rather than skipping "for now."

## Troubleshooting

- **Blank page or 502 right after `docker compose up -d`**: MySQL is
  still initializing. Wait a minute, then reload.
- **On Raspberry Pi / other ARM64 hardware**: the official compose file
  in `app/debian/docker-compose.yml` uses `mysql:8`, which has
  historically had ARM64 compatibility issues on some setups. If MySQL
  won't start, check the Invoice Ninja repo's current guidance on
  swapping to a MariaDB image for ARM — this has changed over time, so
  check `https://github.com/invoiceninja/dockerfiles` directly rather
  than trusting a fixed instruction here.
- **Forgot the admin password after removing `IN_USER_EMAIL`/`IN_PASSWORD`**:
  Invoice Ninja has a password-reset flow from the login page, provided
  you've configured outbound email (SMTP) in `.env` — check
  `https://invoiceninja.github.io/docs/self-host/` for the mail
  configuration variables if you haven't set this up yet.
