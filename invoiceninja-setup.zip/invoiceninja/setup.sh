#!/usr/bin/env bash
# Sets up self-hosted Invoice Ninja by cloning Invoice Ninja's own
# official Docker config (invoiceninja/dockerfiles, debian branch) and
# generating your .env for you.
#
# Why clone instead of shipping our own docker-compose.yml here: Invoice
# Ninja's real setup is nginx + PHP-FPM app + MySQL + Redis, wired
# together with an nginx config tuned specifically for their app. That
# nginx/PHP-FPM proxy config is easy to get subtly wrong and hard to
# verify without a live test. Invoice Ninja's own team maintains and
# tests it directly, so we use theirs rather than reinventing it.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$SCRIPT_DIR/app"

if [ ! -d "$APP_DIR" ]; then
	echo "== Cloning the official Invoice Ninja Docker config (debian branch) =="
	git clone --depth 1 -b debian https://github.com/invoiceninja/dockerfiles.git "$APP_DIR"
	# .env ships as a tracked file in this repo with placeholder values.
	# We're about to fill in real secrets, so tell git to ignore local
	# changes to it — otherwise a later `git pull` for updates fails or
	# tries to overwrite your real credentials with the repo's defaults.
	(cd "$APP_DIR/debian" && git update-index --skip-worktree .env)
else
	echo "== Official config already cloned at $APP_DIR — pulling latest =="
	(cd "$APP_DIR" && git pull)
fi

cd "$APP_DIR/debian"

# The repo ships its own default .env already (not a .env.example), so we
# can't use ".env exists" to detect first run — it always exists right
# after cloning. Use our own marker file instead.
CONFIGURED_MARKER=".invoiceninja-setup-complete"

if [ ! -f "$CONFIGURED_MARKER" ]; then
	echo
	echo "== First-time setup: generating your .env =="

	read -rp "Domain/URL Invoice Ninja will be reached at (e.g. http://localhost:8003 or https://invoices.example.com): " APP_URL
	read -rp "Admin account email: " IN_USER_EMAIL
	read -rsp "Admin account password: " IN_PASSWORD
	echo
	DB_PASSWORD="$(openssl rand -hex 20)"
	DB_ROOT_PASSWORD="$(openssl rand -hex 20)"

	cat > .env <<EOF
APP_URL=${APP_URL}
APP_DEBUG=false
REQUIRE_HTTPS=false
IN_USER_EMAIL=${IN_USER_EMAIL}
IN_PASSWORD=${IN_PASSWORD}
DB_DATABASE=ninja
DB_USERNAME=ninja
DB_PASSWORD=${DB_PASSWORD}
DB_ROOT_PASSWORD=${DB_ROOT_PASSWORD}
EOF

	echo
	echo "== Generating the application key (APP_KEY) =="
	echo "This runs the app image once, just to generate a key, then exits."
	APP_KEY="$(docker run --rm invoiceninja/invoiceninja-debian php artisan key:generate --show)"
	echo "APP_KEY=${APP_KEY}" >> .env

	touch "$CONFIGURED_MARKER"
	echo
	echo "Saved to $APP_DIR/debian/.env — review it before continuing if you want."
else
	echo "== Already configured (found $CONFIGURED_MARKER) — leaving .env as-is =="
	echo "   Delete $APP_DIR/debian/$CONFIGURED_MARKER and re-run this script"
	echo "   if you deliberately want to redo setup from scratch."
fi

echo
echo "== Starting Invoice Ninja (nginx + app + mysql + redis) =="
docker compose up -d

echo
echo "== Done =="
echo "Wait 30-60 seconds for the database to initialize on first run, then open:"
grep '^APP_URL=' .env
echo
echo "Log in with the IN_USER_EMAIL / IN_PASSWORD you set above."
echo "IMPORTANT: once you've confirmed you can log in, remove the IN_USER_EMAIL"
echo "and IN_PASSWORD lines from $APP_DIR/debian/.env and restart"
echo "(docker compose up -d) — these are only meant for first-run account creation."
