# TradeNote + SiYuan + Ollama — self-hosted stack

Three services, two independent Docker Compose stacks:

- **TradeNote** (trading journal) — standalone, own database, port 8080.
- **SiYuan** (notes) + **Ollama** (local AI model) — one stack, since
  SiYuan's AI features talk to Ollama over the internal Docker network.
  SiYuan on port 6806; Ollama is not exposed to your host at all by
  default (nothing outside the SiYuan container needs to reach it).

Everything runs on your own machine. Nothing here requires an internet
connection once the initial images/model are downloaded — including the
AI features, since they run against the local Ollama model instead of
OpenAI's servers.

**A note on "mobile compatible":** the default model
(`qwen2.5:1.5b-instruct-q4_K_M`) is a small, quantized model chosen to
prioritize speed on modest/low-power hardware (roughly 1.5–2GB RAM,
~1GB download, no GPU required) — an old laptop, a NUC, a Raspberry Pi
4/5, etc. Ollama and Docker do not run natively on a phone's OS; you
access SiYuan from your phone's *browser*, while the actual model runs
on whatever machine hosts this stack.

| Model | Download | RAM while running | Use when |
|---|---|---|---|
| `qwen2.5:0.5b-instruct-q4_K_M` | ~400MB | ~0.5–1GB | 1.5B still feels slow; you mostly want quick summaries/rewrites |
| `qwen2.5:1.5b-instruct-q4_K_M` (default) | ~1GB | ~1.5–2GB | Best speed/quality balance for weak hardware |
| `qwen2.5:3b-instruct-q4_K_M` | ~2GB | ~2–3GB | You have RAM to spare and want noticeably better answers |

---

## Prerequisites (once)

```bash
docker --version
docker compose version
```

If missing: install Docker Desktop (Mac/Windows) or Docker Engine + the
compose plugin (Linux). On Linux, avoid needing `sudo` for every command:

```bash
sudo usermod -aG docker $USER
# log out, log back in
```

**Hardware note:** the default 1.5B q4 model needs roughly 1.5–2GB of free
RAM while running — light enough for a Raspberry Pi 4 (4GB+ model) or any
normal laptop. If your machine has 8GB+ RAM to spare and you want
noticeably better AI quality at the cost of speed, swap `OLLAMA_MODEL` for
`qwen2.5:3b-instruct-q4_K_M` (see the table above) — same setup, just a
bigger download and more RAM used while it's answering. Going the other
way, `qwen2.5:0.5b-instruct-q4_K_M` is faster still if 1.5B isn't quick
enough on your hardware.

---

## Setup

```bash
# 1. Configure TradeNote
cd tradenote
cp .env.example .env
openssl rand -hex 24   # -> paste into MONGO_PASSWORD
openssl rand -hex 24   # -> paste into APP_ID
openssl rand -hex 24   # -> paste into MASTER_KEY
nano .env               # paste the three values in, save

# 2. Configure SiYuan + Ollama
cd ../siyuan
cp .env.example .env
openssl rand -base64 18 | tr -d '/+=' | cut -c1-20   # -> paste into SIYUAN_AUTH_CODE
nano .env               # paste it in, set TZ, save
#   (OLLAMA_MODEL is already set to qwen2.5:1.5b-instruct-q4_K_M for speed
#    on modest hardware — leave it unless you want a different model,
#    see the size/RAM table in this README)

# 3. Start everything
cd ..
chmod +x start.sh stop.sh
./start.sh
```

`start.sh` brings up both stacks and waits for the Ollama model to finish
downloading (the model is ~2GB, so this can take a few minutes on the
first run — subsequent restarts skip re-downloading it). It prints the
exact settings to paste into SiYuan when it's done.

To stop everything (without deleting any data):

```bash
./stop.sh
```

---

## First-time use

### TradeNote — http://localhost:8080

Go to `http://localhost:8080/register` and create your one account
(TradeNote is single-tenant per instance — this is just your login, no
email is actually sent). Then log trades manually or import a broker CSV
— check https://github.com/Eleven-Trading/TradeNote/tree/main/brokers
for your broker's exact export format first.

**Backups:** grab `backup-mongodb.sh` from the TradeNote repo
(https://github.com/Eleven-Trading/TradeNote/blob/main/backup-mongodb.sh),
point it at the `tradenote_db` container name (already matches this
compose file), and run it on a cron schedule. That Mongo database is
100% of your trade data.

### SiYuan — http://localhost:6806

Enter the `SIYUAN_AUTH_CODE` you set in `siyuan/.env`. No separate
registration step.

**Turn off Google Analytics immediately** (SiYuan ships this on by
default): Settings → about/account section → disable Google Analytics.

**Connect the local AI model:**
1. Settings → AI (may be labeled "AI" or under an Account/Assistant tab
   depending on your SiYuan version)
2. API provider: **OpenAI-compatible**
3. API base URL: `http://ollama:11434/v1`
   (this works because `ollama` is the other container's name on the
   same Docker network — not `localhost`, since they're separate
   containers)
4. Model: `qwen2.5:1.5b-instruct-q4_K_M` (must match `OLLAMA_MODEL` in
   `siyuan/.env` exactly)
5. API key: leave blank or put any placeholder text — Ollama doesn't
   check it, but some UI fields require something non-empty
6. **Reload SiYuan** — AI setting changes only take effect after a
   reload, this is a known SiYuan quirk

Test it by opening any note and trying whatever AI action your SiYuan
version exposes (summarize, ask a question, etc.). The first response
after a restart can be slow (10-30s) while Ollama loads the model into
memory; after that it stays warm and responds faster.

**Where your notes live:** `siyuan/workspace/` on your host machine.
Back this folder up like any important data — it's not optional, losing
it without a backup means losing every note.

---

## Updating

```bash
cd tradenote && docker compose pull && docker compose up -d && cd ..
cd siyuan && docker compose pull && docker compose up -d && cd ..
```

`docker compose down` (used by `stop.sh`) never deletes your named
volumes or bind-mounted folders — your trades, notes, and downloaded
model all survive restarts and updates. Only `docker compose down -v`
would wipe volumes; avoid that flag unless you explicitly want a clean
slate.

## Switching model speed/quality later

```bash
cd siyuan
# edit .env, change OLLAMA_MODEL to one of:
#   qwen2.5:0.5b-instruct-q4_K_M   (faster, weaker)
#   qwen2.5:1.5b-instruct-q4_K_M   (default)
#   qwen2.5:3b-instruct-q4_K_M     (slower, better)
docker compose up -d ollama-pull   # re-runs just the pull step for the new model
```

Then update the model name in SiYuan's AI settings to match exactly, and
reload. The old model's files stay in the `ollama_data` volume (not
auto-deleted), so switching back and forth doesn't mean re-downloading
every time — only the very first pull of each size is slow.

## Troubleshooting

- **TradeNote can't connect to Mongo on first boot:** try changing
  `mongo:6` to `mongo:5` in `tradenote/docker-compose.yml`, then
  `docker compose up -d --force-recreate`. Mongo version compatibility
  has been reported as version-sensitive by the TradeNote maintainer.
- **SiYuan AI calls fail / time out:** confirm the model finished
  downloading — `docker compose logs ollama-pull` in the `siyuan/`
  folder should end with "Done." If it's still running, wait for it.
- **`docker compose ps` shows `ollama` unhealthy:** give it another
  15-30 seconds after `docker compose up -d` — the healthcheck has a
  `start_period` grace window while the Ollama server initializes.
- **Exposing SiYuan beyond your home network:** don't leave port 6806
  open to the internet directly. Put it behind a reverse proxy (Nginx,
  Caddy, Traefik) with TLS, and change the port line in
  `siyuan/docker-compose.yml` to `"127.0.0.1:6806:6806"` so only the
  proxy can reach it.
