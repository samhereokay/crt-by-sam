#!/usr/bin/env bash
# Stops both stacks. Does NOT delete any data (no -v flag used).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "== Stopping SiYuan + Ollama =="
(cd "$SCRIPT_DIR/siyuan" && docker compose down)

echo "== Stopping TradeNote =="
(cd "$SCRIPT_DIR/tradenote" && docker compose down)

echo "== Done. Your trades, notes, and downloaded model are all still on disk. =="
