#!/usr/bin/env bash
# Starts TradeNote and SiYuan+Ollama, and waits for the Ollama model
# to finish downloading before handing control back to you.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

require_env() {
	local dir="$1"
	if [ ! -f "$dir/.env" ]; then
		echo "ERROR: $dir/.env is missing."
		echo "Run:  cp $dir/.env.example $dir/.env   then edit it, then re-run this script."
		exit 1
	fi
}

echo "== Checking .env files exist =="
require_env "$SCRIPT_DIR/tradenote"
require_env "$SCRIPT_DIR/siyuan"

echo
echo "== Starting TradeNote (app + database) =="
(cd "$SCRIPT_DIR/tradenote" && docker compose up -d)

echo
echo "== Starting SiYuan + Ollama =="
(cd "$SCRIPT_DIR/siyuan" && docker compose up -d)

echo
echo "== Waiting for the Ollama model to finish pulling (first run only, can take a few minutes) =="
(cd "$SCRIPT_DIR/siyuan" && docker compose logs -f ollama-pull) &
LOGS_PID=$!

# Poll until the one-shot pull container exits, then stop tailing its logs.
while true; do
	STATUS="$(cd "$SCRIPT_DIR/siyuan" && docker compose ps -a --format '{{.Name}} {{.State}}' | grep ollama_pull || true)"
	if echo "$STATUS" | grep -q "exited"; then
		break
	fi
	sleep 2
done
kill "$LOGS_PID" 2>/dev/null || true

echo
echo "== All set =="
echo "TradeNote : http://localhost:8080  (first visit: /register to create your account)"
echo "SiYuan    : http://localhost:6806  (enter your SIYUAN_AUTH_CODE from siyuan/.env)"
echo
echo "In SiYuan, go to Settings -> AI and set:"
echo "  API provider : OpenAI-compatible"
echo "  API base URL : http://ollama:11434/v1"
echo "  Model        : (the value of OLLAMA_MODEL in siyuan/.env)"
echo "Then reload SiYuan for the AI settings to take effect."
